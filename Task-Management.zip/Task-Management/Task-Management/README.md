- Create a `.env` file in the root directory.
- Define the following environment variables:
 
  MONGODB_URL=""


- Start the backend server:
`npm start`

- Start the frontend server:
`npm start`
